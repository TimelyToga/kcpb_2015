# kcpb_2015
KCPB Fellowship Application Challenge Question

I created a Makefile, so a clean build can be accomplished with

`make clean`

or the default with

`make`

To compile: 

`javac -sourcepath src -d bin src/*.java`

To test

`java -cp bin TesterClass`

I think these commands are a little wrong.
